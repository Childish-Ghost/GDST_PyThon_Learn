# -*- coding: utf-8 -*-
"""
Created on Mon Apr 26 11:11:24 2021

@author: Administrator
"""
x = (3 ** 4 + 5 * (6 ** 7)) / 8
r = round(x , 3)
print(r)