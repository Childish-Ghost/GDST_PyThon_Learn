# -*- coding: utf-8 -*-
"""
Created on Fri Mar 26 15:22:44 2021

@author: yaoqh
"""

avg_5 = (269 + 621 + 182 + 537 + 366) / 5
print(300 < avg_5 <= 400)
