# -*- coding: utf-8 -*-
"""
Created on Fri Mar 26 15:20:32 2021

@author: yaoqh
"""

num = 279
a = num % 10  # 个位
b = num // 10 % 10  # 十位
c = num // 100  # 百位
re_num = a * 100 + b * 10 + c
print('{}的反转数是:{}'.format(num, re_num))
