# -*- coding: utf-8 -*-
"""
Created on Thu May 20 16:26:52 2021

@author: Administrator
"""
from datetime import datetime

d = datetime(2021, 1, 2)
ts = d.timestamp()
ans = ts / 86400
print(ans)
d2 = datetime(1970, 1, 1)
print(d - d2)