# -*- coding: utf-8 -*-
"""
Created on Fri May 21 10:59:39 2021

@author: Administrator
"""
import random
random.seed()
n = eval(input('请输入正整数：'))
sum = 0
for i in range(n):
    f1 = random.uniform(1, 100)
    sum += f1
    print(f1)
    
print('the average is：', sum / n)