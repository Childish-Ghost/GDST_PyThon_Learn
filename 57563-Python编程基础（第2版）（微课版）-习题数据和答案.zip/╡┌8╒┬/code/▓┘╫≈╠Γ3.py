# -*- coding: utf-8 -*-
"""
Created on Thu May 20 16:26:52 2021

@author: Administrator
"""
import re

text = '张三和李四的出生日期是1999-07-02和1998-05-17'
re.findall('\d{4}-\d{2}-\d{2}', text)


