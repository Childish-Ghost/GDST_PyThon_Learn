# -*- coding: utf-8 -*-
"""
Created on Mon Mar 29 10:37:53 2021

@author: yaoqh
"""

# 打开论语-提取版.txt文件路径
fi = open('../data/论语-提取版.txt', 'r')
# 设置需要保存的文件路径
fo = open('../tmp/论语-原文.txt', 'w')
for line in fi:   # 逐行遍历
    for i in range(1, 23):  # 对产生1到22数字
        line = line.replace('({})'.format(i), '')  # 构造(i)并替换
    fo.write(line)
fi.close()
fo.close()
