# -*- coding: utf-8 -*-
"""
Created on Thu Apr  1 09:24:46 2021

@author: Administrator
"""

# 操作1
list(map(lambda x: x ** 2, [1, 2, 3, 4, 5, 6, 7, 8, 9]))
