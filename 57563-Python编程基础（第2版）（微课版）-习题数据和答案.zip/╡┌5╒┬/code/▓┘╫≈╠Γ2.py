# -*- coding: utf-8 -*-
"""
Created on Thu Apr  1 09:13:54 2021

@author: Administrator
"""
def getInput():
    try:
        txt = input('请输入整数: ')
        while int(txt) != int(txt):
            txt = input('请输入整数: ')
    except:
        return getInput()
    return int(txt)
print(getInput())