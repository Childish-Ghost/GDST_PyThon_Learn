# -*- coding: utf-8 -*-
"""
Created on Thu May 20 16:10:04 2021

@author: Administrator
"""
# 操作题2 使用for循环输出所有3位数中的素数
for i in range(100, 1000):  # 循环获取三位数i
    for j in range(2, i):  # 循环获取2到i-1的数
        if(i % j == 0):  # 若i能够被1和i本身的数除尽则不是素数
            break
    else:
        print(i)  # 输出素数