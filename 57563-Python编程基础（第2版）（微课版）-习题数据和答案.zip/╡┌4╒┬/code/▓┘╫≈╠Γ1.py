# -*- coding: utf-8 -*-
"""
Created on Tue Mar 30 15:21:27 2021

@author: Administrator
"""

# 操作题1 使用列表解析式输出自定义列表[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]中的偶数
list_a = [1, 2, 3, 4, 5, 6, 7, 8, 9]
[x for x in list_a if x % 2 == 0]  # 使用列表解析式输出结果


