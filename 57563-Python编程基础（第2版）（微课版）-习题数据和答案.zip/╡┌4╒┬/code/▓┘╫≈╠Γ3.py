N = input('请输入一个整数: ')
s = 0
for i in range(int(N), int(N) + 100):
    if i % 2 == 1:
        s += i
print(s)