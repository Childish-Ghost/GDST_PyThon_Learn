# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 09:10:37 2021

@author: Administrator
"""
# 操作1
# 定义住房面积（HouseArea）类
class HouseArea:
    def __init__(self, living_area, kitchen_area, bed_area):  # 定义类属性
        self.living_area = living_area
        self.kitchen_area = kitchen_area
        self.bed_area = bed_area
        
    def get_living_area(self):  # 定义类方法
        print(self.living_area)

# 调用住房面积类
house_area = HouseArea(40, 30, 50)
print(house_area.get_living_area())
