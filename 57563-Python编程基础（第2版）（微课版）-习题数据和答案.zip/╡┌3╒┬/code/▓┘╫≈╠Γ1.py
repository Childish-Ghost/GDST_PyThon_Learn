# -*- coding: utf-8 -*-
"""
Created on Thu May 20 16:00:32 2021

@author: Administrator
"""
# 操作题1
# 创建列表
li = [1, 2, 3, 4, 5, 6]
# 添加元素
li.append('x')
li.append('y')
li.append(9)
print(li)
# 修改元素值
li[0:3] = []
# 删除元素
li.remove(5)
li.remove(6)
print(li)
