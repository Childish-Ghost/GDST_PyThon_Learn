# -*- coding: utf-8 -*-
"""
Created on Thu May 20 16:00:32 2021

@author: Administrator
"""
# 操作题2
# 创建列表
dic = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
# 循环输出键值对
key = dic.keys()
for i in key:
    print('{0}: {1} '.format(i, dic[i]))
# 添加键值对
dic['key4'] = 'value4'
# 修改数据
dic['key1'] = 1
print(dic)
