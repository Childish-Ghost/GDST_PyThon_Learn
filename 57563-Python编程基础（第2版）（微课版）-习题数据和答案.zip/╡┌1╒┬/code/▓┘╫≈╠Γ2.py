# -*- coding: utf-8 -*-
"""
Created on Mon Mar 29 14:34:21 2021

@author: yaoqh
"""

input_1 = input()  # 在控制台中输入'Nice to meet you Python'
print(input_1)
