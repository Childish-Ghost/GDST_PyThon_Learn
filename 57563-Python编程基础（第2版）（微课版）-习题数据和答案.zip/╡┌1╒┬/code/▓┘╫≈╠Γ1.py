# -*- coding: utf-8 -*-
"""
Created on Mon Mar 29 14:34:06 2021

@author: yaoqh
"""

# 第一种输出方式
print('Nice to meet you Python')
# 第二种输出方式
output_2 = 'Nice to meet you Python'
print(output_2)
