# -*- coding: utf-8 -*-
"""
Created on Mon Apr 26 09:42:29 2021

@author: Administrator
"""
a = input('请输入一个整数：')
x = input('请输入一个字符：')
print('整数为：', int(a))
print('字符为：', x)
